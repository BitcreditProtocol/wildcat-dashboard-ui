# AI Credit operator presentation

Private, host-neutral React presentation for synthetic/testnet investigation receipts.
`ClaimInvestigationPanel` takes an already validated shared `ClaimInvestigationState`;
`CaseInvestigationPanel` takes the bounded answer-review, information-need and
optional public-research projections from an operator case. It presents the
recorded trigger, question, applicant response and evidence-review basis together;
an answer never becomes verified just because it is present. Stale reviews and
exhausted investigations remain visibly unresolved. Completed evidence follow-ups
can collapse without removing their provenance.
When the host supplies the current applicant confirmation, unresolved questions
from earlier prepared inputs start collapsed but still count as current evidence
gates. Without that input identity, unresolved questions stay expanded.
`historicalInformationNeeds` stays read-only and never contributes to the current
unresolved summary. Explicit run/need origin links suppress a duplicate proposal;
the view does not infer lineage by matching question text.
The host supplies React Intl and its Tailwind v4 theme, including scanning this
package's emitted JavaScript for utility classes. Fixed chrome uses `credit.*`
message descriptors with English defaults; source titles, excerpts and summaries
remain untrusted text in their original language.

The panels have no fetch client, credentials, router or background work. The host
may supply the existing controlled proposal-selection callback; selecting a
proposal does not admit it or contact the applicant. Research-panel URLs render
as text. Public-context follow-up citations use schema-validated, credential-free
public HTTPS links, opened only on an operator click in a new tab without a
referrer. Source content remains untrusted; there is no automatic navigation.
Disabled research renders nothing; idle means not started, not a promise
that a worker is running. Public context never verifies a case or authorizes terms.
Recorded search terms are shown separately from model-cited source titles, URLs
and excerpts. New `toolReceipts` show observed completion timestamps, including
opaque actions for which no target is available. Historical records without
receipts keep their search terms without invented timestamps or tool events.
A citation or opaque action does not establish that a page was retrieved.
Answer-review findings are source-bound display proposals. They do not become
governed information needs, block an operator action or contact an applicant.

Both panels are exported. Host integration, runtime activation and packaged
distribution are separate steps.

`updatesStatus` is an optional host-supplied polling/subscription status on
`CaseInvestigationPanel`. Omission makes no live claim. During reconnect or
unavailability, saved status is labelled as last recorded and proposal selection
is disabled; retained results are not replaced by an endless running indicator.
`ClaimInvestigationPanel` also accepts `embedded` for the unified investigation
surface, avoiding a second collapsed research panel in that view.
